# GigaSearch Investment Agent (RAG / noRAG) + LangGraph

Проект разделён на:
- **scripts/** — оффлайн-скрипты для создания dataset + индекса (вне сессии агента)
- **run_agent.py** — запуск диалоговой сессии агента (контекст сохраняется в файл)
- **src/** — библиотечный код (клиент + агент + граф)
- **configs/** — все константы и конфиги (включая index_id в search config)

## Быстрый старт

1) Установите зависимости:

```bash
pip install -r requirements.txt
```

2) Проверьте `configs/app.yaml`:
- `gigasearch.base_url`
- `gigasearch.source_uuid`
- пути к сертификату и ключу
- пути к search config файлам
- `agent.mode` (rag|norag|auto)

3) Запуск агента:

```bash
python run_agent.py
```

Команды в CLI:
- `/help` — справка
- `/mode rag|norag|auto` — переключение режима
- `/product <product_name>` — фильтрация по product_name (keyword-атрибут в индексе)
- `/clear` — очистить историю
- `/state` — показать состояние
- `exit` — выход

## Оффлайн создание индекса (вне сессии агента)

Скрипт:
```bash
python scripts/build_index.py --config configs/indexing.yaml
```

Также приложен ноутбук: `scripts/build_index.ipynb`.
