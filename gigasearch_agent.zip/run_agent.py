import os
import sys
import json
from pathlib import Path

# --- make ./src importable ---
ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from gigasearch import GigaSearchClient  # noqa: E402
from agent import build_agent_graph, FileStateStore, load_settings  # noqa: E402
from agent.settings import load_json, load_yaml, deep_update  # noqa: E402


def load_search_configs(settings):
    rag_cfg = load_json(settings.paths.search_rag_path)
    norag_cfg = load_json(settings.paths.search_norag_path)

    # Опционально применяем "строгие" промпты (map/reduce/norag)
    if settings.paths.prompts_strict_path:
        strict = load_yaml(settings.paths.prompts_strict_path) or {}
        strict_prompts = (strict.get("qa") or {}).get("prompts") or {}
        if strict_prompts:
            patch = {"agent_configuration": {"qa": {"prompts": strict_prompts}}}
            rag_cfg = deep_update(rag_cfg, patch)

    return rag_cfg, norag_cfg


def main():
    settings = load_settings(str(ROOT / "configs" / "app.yaml"))

    rag_cfg, norag_cfg = load_search_configs(settings)

    client = GigaSearchClient(
        base_url=settings.gigasearch.base_url,
        source_uuid=settings.gigasearch.source_uuid,
        cert=settings.gigasearch.cert,
        verify_ssl=settings.gigasearch.verify_ssl,
        timeout_sec=settings.gigasearch.timeout_sec,
    )

    agent_graph = build_agent_graph(
        client=client,
        settings=settings,
        search_cfg_rag=rag_cfg,
        search_cfg_norag=norag_cfg,
    )

    store = FileStateStore(settings.agent.state_path)
    state = store.load(default_mode=settings.agent.mode)

    print("🤖 Investment Agent (LangGraph) | mode =", state.get("mode"))
    print("Команды: /help, /mode rag|norag|auto, /product <name>, /clear, /state, exit\n")

    while True:
        try:
            user_input = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n[system] exit")
            break

        if not user_input:
            continue

        if user_input.lower() in ("exit", "quit"):
            print("[system] exit")
            break

        # добавляем user сообщение в state
        msgs = state.get("messages", [])
        msgs.append({"role": "user", "content": user_input})
        state["messages"] = msgs

        # прогоняем граф
        try:
            state = agent_graph.invoke(state)
        except Exception as e:
            # сохраняем, чтобы не потерять контекст
            store.save(state)
            print(f"[error] {type(e).__name__}: {e}")
            continue

        # сохраняем состояние между запусками
        store.save(state)

        # печатаем последний ассистентский ответ (если есть)
        if state.get("messages") and state["messages"][-1].get("role") == "assistant":
            print(state["messages"][-1]["content"])
        else:
            print("[system] (no assistant message)")

        print()

    # финальное сохранение
    try:
        store.save(state)
    except Exception:
        pass


if __name__ == "__main__":
    main()
