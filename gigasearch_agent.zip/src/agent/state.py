import json
from enum import Enum
from typing import Any, Dict, List, Optional, TypedDict


class AgentMode(str, Enum):
    RAG = "rag"
    NORAG = "norag"
    AUTO = "auto"


class AgentState(TypedDict, total=False):
    # Диалог (для передачи в universal_search в формате messages=[{role, content}, ...])
    messages: List[Dict[str, str]]

    # Режим работы
    mode: str  # rag|norag|auto

    # Фильтры
    active_product: Optional[str]

    # Служебное
    awaiting_user_clarification: bool
    last_result: Optional[Dict[str, Any]]
    last_route: Optional[str]  # rag|norag|command
    last_classification: Optional[Dict[str, Any]]

    # Для langgraph router
    next_node: Optional[str]  # rag|norag|end


def default_state(mode: str = "rag") -> AgentState:
    return AgentState(
        messages=[],
        mode=mode,
        active_product=None,
        awaiting_user_clarification=False,
        last_result=None,
        last_route=None,
        last_classification=None,
        next_node=None,
    )


def extract_agent_text(result: Dict[str, Any]) -> str:
    """Корректно извлекаем текст ответа universal_search."""
    try:
        messages = (
            result
            .get("result", {})
            .get("response", {})
            .get("messages", [])
        )
        for msg in reversed(messages):
            if msg.get("role") == "assistant" and msg.get("content"):
                return msg["content"]
    except Exception:
        pass

    # fallback: pretty json
    return json.dumps(result, ensure_ascii=False, indent=2)


def is_clarification(text: str) -> bool:
    t = (text or "").strip()
    return t.endswith("?") and len(t) > 1


def trim_history(
    messages: List[Dict[str, str]],
    keep_last_user_turns: int,
    awaiting_clarification: bool,
) -> List[Dict[str, str]]:
    """
    Обрезаем историю, чтобы не раздувать контекст.
    ВАЖНО: если агент задал уточняющий вопрос — историю не режем,
    чтобы пользователь мог ответить в рамках того же контекста.
    """
    if awaiting_clarification:
        return messages

    user_idxs = [i for i, m in enumerate(messages) if m.get("role") == "user"]
    if len(user_idxs) <= keep_last_user_turns:
        return messages

    cutoff = user_idxs[-keep_last_user_turns]
    return messages[cutoff:]


def normalize_user_text(text: str) -> str:
    return (text or "").strip()


def message_count(messages: List[Dict[str, str]]) -> Dict[str, int]:
    u = sum(1 for m in messages if m.get("role") == "user")
    a = sum(1 for m in messages if m.get("role") == "assistant")
    return {"user": u, "assistant": a, "total": len(messages)}
