import json
import os
import tempfile
from pathlib import Path
from typing import Any, Dict, Optional

from .state import AgentState, default_state


class FileStateStore:
    """Простое файловое хранилище состояния агента (контекст между запусками)."""

    def __init__(self, path: str):
        self.path = Path(path)

    def load(self, *, default_mode: str = "rag") -> AgentState:
        if not self.path.exists():
            return default_state(default_mode)

        with self.path.open("r", encoding="utf-8") as f:
            data: Dict[str, Any] = json.load(f)

        # минимальная валидация/совместимость
        if "messages" not in data:
            data["messages"] = []
        if "mode" not in data:
            data["mode"] = default_mode

        return AgentState(**data)

    def save(self, state: AgentState) -> None:
        self.path.parent.mkdir(parents=True, exist_ok=True)

        payload = json.loads(json.dumps(state, ensure_ascii=False))

        # atomic write
        fd, tmp = tempfile.mkstemp(prefix=self.path.name, dir=str(self.path.parent))
        try:
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                json.dump(payload, f, ensure_ascii=False, indent=2)
            os.replace(tmp, self.path)
        finally:
            try:
                if os.path.exists(tmp):
                    os.remove(tmp)
            except Exception:
                pass
