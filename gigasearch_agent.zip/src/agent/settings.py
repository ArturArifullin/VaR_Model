import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

from gigasearch.utils import ensure_cert_tuple


@dataclass(frozen=True)
class GigaSearchSettings:
    base_url: str
    source_uuid: str
    cert: Tuple[str, str]
    verify_ssl: bool
    timeout_sec: int


@dataclass(frozen=True)
class AgentSettings:
    state_path: str
    mode: str  # rag|norag|auto
    keep_last_user_turns: int
    product_filter_field: str


@dataclass(frozen=True)
class PathsSettings:
    search_rag_path: str
    search_norag_path: str
    prompts_strict_path: Optional[str] = None


@dataclass(frozen=True)
class DomainSettings:
    known_products: List[str]


@dataclass(frozen=True)
class AppSettings:
    gigasearch: GigaSearchSettings
    agent: AgentSettings
    paths: PathsSettings
    domain: DomainSettings


def load_yaml(path: str) -> Dict[str, Any]:
    p = Path(path)
    with p.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def load_json(path: str) -> Dict[str, Any]:
    p = Path(path)
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)


def deep_update(base: Dict[str, Any], patch: Dict[str, Any]) -> Dict[str, Any]:
    """Рекурсивное обновление base <- patch (не мутирует base)."""
    out = json.loads(json.dumps(base))
    stack = [(out, patch)]
    while stack:
        dst, src = stack.pop()
        for k, v in (src or {}).items():
            if isinstance(v, dict) and isinstance(dst.get(k), dict):
                stack.append((dst[k], v))
            else:
                dst[k] = v
    return out


def load_settings(app_yaml_path: str) -> AppSettings:
    cfg = load_yaml(app_yaml_path)

    gs = cfg.get("gigasearch") or {}
    cert_cfg = (gs.get("cert") or {})
    cert = ensure_cert_tuple(
        cert_cfg.get("crt_path", ""),
        cert_cfg.get("key_path", ""),
    )

    paths = cfg.get("paths") or {}
    agent = cfg.get("agent") or {}
    domain = cfg.get("domain") or {}

    return AppSettings(
        gigasearch=GigaSearchSettings(
            base_url=gs.get("base_url", ""),
            source_uuid=gs.get("source_uuid", ""),
            cert=cert,
            verify_ssl=bool(gs.get("verify_ssl", False)),
            timeout_sec=int(gs.get("timeout_sec", 600)),
        ),
        paths=PathsSettings(
            search_rag_path=str(paths.get("search_rag_path", "")),
            search_norag_path=str(paths.get("search_norag_path", "")),
            prompts_strict_path=str(paths.get("prompts_strict_path")) if paths.get("prompts_strict_path") else None,
        ),
        agent=AgentSettings(
            state_path=str(agent.get("state_path", "./.state/agent_state.json")),
            mode=str(agent.get("mode", "rag")).lower(),
            keep_last_user_turns=int(agent.get("keep_last_user_turns", 3)),
            product_filter_field=str(agent.get("product_filter_field", "product_name")),
        ),
        domain=DomainSettings(
            known_products=list(domain.get("known_products") or []),
        ),
    )
