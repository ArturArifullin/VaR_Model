class GigaSearchError(RuntimeError):
    """Единый тип исключения для ошибок API (dataset/index/chat)."""
    pass
