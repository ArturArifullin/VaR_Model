import json
import os
import time
from typing import Any, Dict, List, Optional, Tuple, Union

import requests

from .errors import GigaSearchError
from .utils import guess_mime, raise_for_status, uuid4_str


class GigaSearchClient:
    """
    Клиент для работы с:
    - dataset
    - upload файлов
    - versioning
    - indexing
    - chat/search (RAG / noRAG через universal_search)

    ВАЖНО:
    - upload_files НЕ делает version/save
    - version/save — fire-and-forget
    - всегда ждём status=DONE через GET /dataset/{id}/version
    """

    def __init__(
        self,
        base_url: str,
        source_uuid: str,
        cert: Tuple[str, str],
        verify_ssl: bool = False,
        timeout_sec: int = 600,
    ):
        self.base_url = base_url.rstrip("/")
        self.source_uuid = source_uuid
        self.cert = cert
        self.verify_ssl = verify_ssl
        self.timeout_sec = timeout_sec

        self._headers_json = {
            "accept": "application/json",
            "Content-Type": "application/json",
        }

        self._headers_upload = {
            "accept": "application/json",
        }

    # ----------------------------
    # Low-level HTTP
    # ----------------------------

    def _post_json(self, path: str, payload: Dict[str, Any], context: str) -> Dict[str, Any]:
        resp = requests.post(
            f"{self.base_url}/{path.lstrip('/')}" ,
            headers=self._headers_json,
            json=payload,
            cert=self.cert,
            verify=self.verify_ssl,
            timeout=self.timeout_sec,
        )
        raise_for_status(resp, context)
        try:
            return resp.json()
        except Exception:
            return {}

    def _get_json(self, path: str, context: str) -> Union[Dict[str, Any], List[Any]]:
        resp = requests.get(
            f"{self.base_url}/{path.lstrip('/')}" ,
            headers=self._headers_json,
            cert=self.cert,
            verify=self.verify_ssl,
            timeout=self.timeout_sec,
        )
        raise_for_status(resp, context)
        try:
            return resp.json()
        except Exception:
            return {}

    # ----------------------------
    # Dataset
    # ----------------------------

    def create_dataset(
        self,
        enrichment_config: Dict[str, Any],
        metadata: Optional[Dict[str, Any]] = None,
    ) -> str:
        payload = {
            "source_uuid": self.source_uuid,
            "data_enrichment_skill": "data_enrichment",
            "data_enrichment_config": enrichment_config,
            "metadata": metadata or {},
        }

        res = self._post_json("/dataset", payload, "Create dataset")
        dataset_uuid = res.get("dataset_uuid")

        if not dataset_uuid:
            raise GigaSearchError(f"dataset_uuid not found in response: {res}")

        return dataset_uuid

    # ----------------------------
    # Upload files
    # ----------------------------

    def upload_files(
        self,
        dataset_uuid: str,
        paths: Union[str, List[str]],
        product_name: str,
        extra_metadata: Optional[Dict[str, Any]] = None,
    ) -> None:
        if isinstance(paths, str):
            paths = [paths]

        for path in paths:
            if not os.path.exists(path):
                raise FileNotFoundError(path)

            file_name = os.path.basename(path)
            mime = guess_mime(path)

            metadata: Dict[str, Any] = {
                "type": "document",
                "attributes": [
                    {
                        "name": "product_name",
                        "value": product_name,
                        "type": "keyword",
                    }
                ],
            }
            if extra_metadata:
                metadata.update(extra_metadata)

            payload_metadata = [
                {"path": file_name, "metadata": metadata}
            ]

            with open(path, "rb") as f:
                files = {
                    "source_uuid": (None, self.source_uuid),
                    "files": (file_name, f, mime),
                    "paths": (None, file_name),
                    "metadata": (None, json.dumps(payload_metadata, ensure_ascii=False)),
                }

                resp = requests.post(
                    f"{self.base_url}/dataset/{dataset_uuid}/file",
                    headers=self._headers_upload,
                    files=files,
                    cert=self.cert,
                    verify=self.verify_ssl,
                    timeout=self.timeout_sec,
                )

            raise_for_status(resp, f"Upload file {file_name}")

    # ----------------------------
    # Dataset versioning
    # ----------------------------

    def save_dataset_version(self, dataset_uuid: str) -> None:
        """
        Fire-and-forget.
        Response может быть {} — это НОРМА.
        """
        resp = requests.post(
            f"{self.base_url}/dataset/{dataset_uuid}/version/save",
            headers=self._headers_json,
            json={},
            cert=self.cert,
            verify=self.verify_ssl,
            timeout=self.timeout_sec,
        )
        if resp.status_code not in (200, 201):
            raise GigaSearchError(
                f"Save dataset version failed: {resp.status_code} {resp.text}"
            )

    def list_dataset_versions(self, dataset_uuid: str) -> List[Dict[str, Any]]:
        res = self._get_json(f"/dataset/{dataset_uuid}/version", "List dataset versions")
        if isinstance(res, list):
            return res
        raise GigaSearchError(f"Unexpected versions response: {res}")

    def wait_last_version_done(
        self,
        dataset_uuid: str,
        poll_sec: float = 3.0,
        max_wait_sec: int = 900,
    ) -> Dict[str, Any]:
        deadline = time.time() + max_wait_sec
        last_seen: Optional[Dict[str, Any]] = None

        while time.time() < deadline:
            versions = self.list_dataset_versions(dataset_uuid)
            if versions:
                last = versions[-1]
                last_seen = last
                status = (last.get("status") or "").upper()

                if status == "DONE":
                    return last

                if status == "ERROR":
                    raise GigaSearchError(f"Dataset version ERROR: {last}")

            time.sleep(poll_sec)

        raise GigaSearchError(
            f"Timeout waiting dataset version DONE. Last seen: {last_seen}"
        )

    # ----------------------------
    # Index
    # ----------------------------

    def create_index(
        self,
        dataset_uuid: str,
        indexer_config: Dict[str, Any],
        index_id: Optional[str] = None,
    ) -> str:
        cfg = json.loads(json.dumps(indexer_config))  # deep copy

        # подставляем dataset_uuid в data_sources
        for src in cfg.get("data_sources", []):
            src["dataset_uuid"] = dataset_uuid

        cfg.update({
            "source_uuid": self.source_uuid,
            "delete_existing": True,
            "index_id": index_id or f"{uuid4_str()}_general_demo_index",
            "autoindex": False,
        })

        res = self._post_json("/index/create", cfg, "Create index")
        index_uuid = res.get("index_uuid")

        if not index_uuid:
            raise GigaSearchError(f"index_uuid not found in response: {res}")

        return index_uuid

    def update_index(self, index_uuid: str) -> None:
        self._post_json(f"/index/{index_uuid}/update", {}, "Update index")

    def get_index(self, index_uuid: str) -> Dict[str, Any]:
        res = self._get_json(f"/index/{index_uuid}", "Get index")
        if isinstance(res, dict):
            return res
        raise GigaSearchError(f"Unexpected index response: {res}")

    def wait_index_done(
        self,
        index_uuid: str,
        poll_sec: float = 3.0,
        max_wait_sec: int = 900,
    ) -> Dict[str, Any]:
        deadline = time.time() + max_wait_sec
        last_seen: Optional[Dict[str, Any]] = None

        while time.time() < deadline:
            st = self.get_index(index_uuid)
            last_seen = st
            status = (st.get("status") or "").upper()

            if status in ("DONE", "PROCESSING_DONE"):
                return st

            if "ERROR" in status:
                raise GigaSearchError(f"Index ERROR: {st}")

            time.sleep(poll_sec)

        raise GigaSearchError(
            f"Timeout waiting index DONE. Last seen: {last_seen}"
        )

    # ----------------------------
    # Universal Search Skill (Chat)
    # ----------------------------

    def chat_messages(
        self,
        messages: List[Dict[str, str]],
        search_config: Dict[str, Any],
        *,
        request_filter: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        """
        Диалоговый формат (messages) в точности как в документации universal_search:
        request.messages = [{role, content}, ...]
        """

        request: Dict[str, Any] = {"messages": messages}
        if request_filter:
            request["filter"] = request_filter

        payload = {
            "meta": {
                "external_uuid": uuid4_str(),
                "source_uuid": self.source_uuid,
            },
            "message": {
                "request_type": "chat",
                "request": request,
            },
            "path": "/predict",
            "timeout": self.timeout_sec,
            "configuration": search_config,
        }

        return self._post_json(
            "/sync/skill/universal_search",
            payload,
            "Chat request",
        )

    def chat(
        self,
        question: str,
        search_config: Dict[str, Any],
    ) -> Dict[str, Any]:
        return self.chat_messages(
            messages=[{"role": "user", "content": question}],
            search_config=search_config,
        )

    def chat_with_product_filter(
        self,
        question: str,
        product_name: str,
        search_config: Dict[str, Any],
    ) -> Dict[str, Any]:
        return self.chat_messages(
            messages=[{"role": "user", "content": question}],
            search_config=search_config,
            request_filter={
                "operator": "eq",
                "field": "product_name",
                "value": product_name,
            }
        )

    def chat_messages_with_product_filter(
        self,
        messages: List[Dict[str, str]],
        product_name: str,
        search_config: Dict[str, Any],
    ) -> Dict[str, Any]:
        return self.chat_messages(
            messages=messages,
            search_config=search_config,
            request_filter={
                "operator": "eq",
                "field": "product_name",
                "value": product_name,
            }
        )
