# GigaSearch Investment Agent (RAG / noRAG / Individual Index) + LangGraph

## Что есть в проекте
- `run_agent.py` — CLI агент с сохранением состояния в `.state/agent_state.json`
- Режимы: `rag`, `norag`, `auto`
- Команды:
  - `/help`
  - `/mode rag|norag|auto`
  - `/product <product_name>`
  - `/add_pass_to_individual_index <path>` — создаёт отдельный dataset + index под один паспорт и заполняет JSON-анкеты из `configs/individual_questions.json`
  - `/clear`, `/state`, `exit`

## Важно про индексацию
- Основной индекс (для RAG режима) создаётся **вне** сессии агента: `scripts/build_index.py`.
- Для `/add_pass_to_individual_index` индекс создаётся “на лету” под один файл (это отдельный flow/нода графа).

## Установка
```bash
pip install -r requirements.txt
```

## Запуск
```bash
python run_agent.py
```

## Оффлайн создание общего индекса (RAG)
```bash
python scripts/build_index.py --config configs/indexing.yaml
```
