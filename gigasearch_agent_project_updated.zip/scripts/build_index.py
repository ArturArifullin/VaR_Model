import argparse
import json
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from gigasearch import GigaSearchClient  # noqa: E402
from agent.settings import load_yaml, load_json  # noqa: E402


def main():
    ap = argparse.ArgumentParser(description="Create dataset + upload + create index (offline)")
    ap.add_argument("--config", default=str(ROOT / "configs" / "indexing.yaml"), help="Path to indexing.yaml")
    args = ap.parse_args()

    cfg = load_yaml(args.config)

    gs = cfg.get("gigasearch") or {}
    cert_cfg = (gs.get("cert") or {})

    client = GigaSearchClient(
        base_url=str(gs.get("base_url", "")).rstrip("/"),
        source_uuid=str(gs.get("source_uuid", "")),
        cert=(str(cert_cfg.get("crt_path", "")), str(cert_cfg.get("key_path", ""))),
        verify_ssl=bool(gs.get("verify_ssl", False)),
        timeout_sec=int(gs.get("timeout_sec", 600)),
    )

    paths = cfg.get("paths") or {}
    de_cfg = load_yaml(str(paths.get("data_enrichment_config")))
    indexer_cfg = load_json(str(paths.get("indexer_config")))

    index_section = cfg.get("index") or {}
    index_id = index_section.get("index_id") or None

    print("[1/5] create dataset ...")
    dataset_uuid = client.create_dataset(de_cfg)
    print("dataset_uuid =", dataset_uuid)

    print("[2/5] upload files ...")
    uploads = cfg.get("upload") or []
    for u in uploads:
        path = u["path"]
        product_name = u["product_name"]
        print(f" - upload: {path}  (product_name={product_name})")
        client.upload_files(dataset_uuid, path, product_name=product_name)

    print("[3/5] save dataset version + wait DONE ...")
    client.save_dataset_version(dataset_uuid)
    last_ver = client.wait_last_version_done(dataset_uuid)
    print("dataset_version =", json.dumps(last_ver, ensure_ascii=False, indent=2))

    print("[4/5] create index ...")
    index_uuid = client.create_index(dataset_uuid, indexer_cfg, index_id=index_id)
    print("index_uuid =", index_uuid)

    print("[5/5] update index + wait DONE ...")
    client.update_index(index_uuid)
    index_status = client.wait_index_done(index_uuid)
    print("index_status =", json.dumps(index_status, ensure_ascii=False, indent=2))

    final_index_id = index_status.get("index_id") or index_id or indexer_cfg.get("index_id")
    print("\n=== RESULT ===")
    print("dataset_uuid:", dataset_uuid)
    print("index_uuid:", index_uuid)
    print("index_id  :", final_index_id)
    print("\nТеперь проставьте index_id в configs/search_dialog_chat_map_reduce.json и configs/search_dialog_chat_norag.json.")


if __name__ == "__main__":
    main()
