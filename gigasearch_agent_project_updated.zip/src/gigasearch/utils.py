import json
import mimetypes
import uuid
from typing import Any, Dict, Tuple, Union

import requests

from .errors import GigaSearchError


def uuid4_str() -> str:
    return str(uuid.uuid4())


def guess_mime(path: str) -> str:
    mt, _ = mimetypes.guess_type(path)
    return mt or "application/octet-stream"


def raise_for_status(resp: requests.Response, context: str) -> None:
    if 200 <= resp.status_code < 300:
        return
    try:
        body: Union[Dict[str, Any], str] = resp.json()
    except Exception:
        body = resp.text

    raise GigaSearchError(
        f"{context} failed\n"
        f"HTTP {resp.status_code}\n"
        f"URL: {resp.url}\n"
        f"Response: {json.dumps(body, ensure_ascii=False, indent=2) if isinstance(body, dict) else body}"
    )


def ensure_cert_tuple(crt_path: str, key_path: str) -> Tuple[str, str]:
    return (crt_path, key_path)
