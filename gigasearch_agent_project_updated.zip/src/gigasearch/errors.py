class GigaSearchError(RuntimeError):
    pass
