import json
from enum import Enum
from typing import Any, Dict, List, Optional, TypedDict


class AgentMode(str, Enum):
    RAG = "rag"
    NORAG = "norag"
    AUTO = "auto"


class AgentState(TypedDict, total=False):
    messages: List[Dict[str, str]]

    mode: str  # rag|norag|auto
    active_product: Optional[str]

    awaiting_user_clarification: bool
    last_result: Optional[Dict[str, Any]]
    last_route: Optional[str]
    last_classification: Optional[Dict[str, Any]]

    next_node: Optional[str]  # rag|norag|individual_index|end

    # --- /add_pass_to_individual_index ---
    individual_passport_path: Optional[str]
    individual_last_dataset_uuid: Optional[str]
    individual_last_index_id: Optional[str]
    individual_last_output_path: Optional[str]


def default_state(mode: str = "rag") -> AgentState:
    return AgentState(
        messages=[],
        mode=mode,
        active_product=None,
        awaiting_user_clarification=False,
        last_result=None,
        last_route=None,
        last_classification=None,
        next_node=None,
        individual_passport_path=None,
        individual_last_dataset_uuid=None,
        individual_last_index_id=None,
        individual_last_output_path=None,
    )


def extract_agent_text(result: Dict[str, Any]) -> str:
    """Extract assistant message from universal_search response."""
    try:
        messages = result.get("result", {}).get("response", {}).get("messages", [])
        for msg in reversed(messages):
            if msg.get("role") == "assistant" and msg.get("content"):
                return msg["content"]
    except Exception:
        pass
    return json.dumps(result, ensure_ascii=False, indent=2)


def is_clarification(text: str) -> bool:
    t = (text or "").strip()
    return t.endswith("?") and len(t) > 1


def normalize_user_text(text: str) -> str:
    return (text or "").strip()


def trim_history(messages: List[Dict[str, str]], keep_last_user_turns: int, awaiting_clarification: bool) -> List[Dict[str, str]]:
    if awaiting_clarification:
        return messages
    user_idxs = [i for i, m in enumerate(messages) if m.get("role") == "user"]
    if len(user_idxs) <= keep_last_user_turns:
        return messages
    cutoff = user_idxs[-keep_last_user_turns]
    return messages[cutoff:]
