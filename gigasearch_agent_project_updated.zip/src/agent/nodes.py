import json
from typing import Any, Dict, List, Optional

from gigasearch.client import GigaSearchClient

from .individual_index import run_add_pass_to_individual_index
from .settings import AppSettings
from .state import AgentState, extract_agent_text, is_clarification, normalize_user_text, trim_history

_RAG_HINTS = [
    "паспорт", "купон", "купонный", "барьер", "автоколл", "autocall",
    "базовый актив", "isin", "доходность", "срок", "погаш", "досроч",
    "условия", "номинал", "эмитент", "наблюдени", "корзин", "страйк",
]


def _find_product_in_text(text: str, known_products: List[str]) -> Optional[str]:
    t = (text or "").lower()
    for p in known_products:
        if p.lower() in t:
            return p
    return None


def classify_query(text: str, known_products: List[str], active_product: Optional[str]) -> Dict[str, Any]:
    normalized = (text or "").strip()
    product = _find_product_in_text(normalized, known_products)

    if active_product:
        return {"route": "rag", "reason": "active_product is set", "product": active_product}

    if product:
        return {"route": "rag", "reason": "product mentioned in user text", "product": product}

    t_low = normalized.lower()
    if any(h in t_low for h in _RAG_HINTS):
        return {"route": "rag", "reason": "rag hints detected", "product": None}

    return {"route": "norag", "reason": "default heuristic", "product": None}


def _strip_quotes(s: str) -> str:
    s = s.strip()
    if (s.startswith('"') and s.endswith('"')) or (s.startswith("'") and s.endswith("'")):
        return s[1:-1].strip()
    return s


def handle_command(state: AgentState, text: str, settings: AppSettings) -> Optional[AgentState]:
    cmd = (text or "").strip()
    if not cmd.startswith("/"):
        return None

    parts = cmd.split(maxsplit=2)
    name = parts[0].lower()

    if name in ("/help", "/?"):
        msg = (
            "Команды:\n"
            "  /help                         — справка\n"
            "  /mode rag|norag|auto           — переключить режим\n"
            "  /product <product_name>        — фильтр по product_name\n"
            "  /add_pass_to_individual_index <path> — dataset+index под один паспорт и заполнение анкеты\n"
            "  /clear                         — очистить историю\n"
            "  /state                         — показать состояние\n"
            "  /products                      — список известных продуктов\n"
        )
        st = state.copy()
        st["messages"] = st.get("messages", []) + [{"role": "assistant", "content": msg}]
        st["last_route"] = "command"
        st["next_node"] = "end"
        return st

    if name == "/products":
        known = settings.domain.known_products
        msg = "Известные продукты:\n" + "\n".join(f"- {p}" for p in known) if known else "Список известных продуктов пуст."
        st = state.copy()
        st["messages"] = st.get("messages", []) + [{"role": "assistant", "content": msg}]
        st["last_route"] = "command"
        st["next_node"] = "end"
        return st

    if name == "/mode":
        st = state.copy()
        if len(parts) < 2:
            msg = "Использование: /mode rag|norag|auto"
            st["messages"] = st.get("messages", []) + [{"role": "assistant", "content": msg}]
            st["last_route"] = "command"
            st["next_node"] = "end"
            return st

        m = parts[1].lower()
        if m not in ("rag", "norag", "auto"):
            msg = "Некорректный режим. Доступно: rag, norag, auto"
            st["messages"] = st.get("messages", []) + [{"role": "assistant", "content": msg}]
            st["last_route"] = "command"
            st["next_node"] = "end"
            return st

        st["mode"] = m
        st["messages"] = st.get("messages", []) + [{"role": "assistant", "content": f"[system] mode = {m}"}]
        st["last_route"] = "command"
        st["next_node"] = "end"
        return st

    if name == "/product":
        st = state.copy()
        if len(parts) < 2:
            msg = "Использование: /product <product_name>"
            st["messages"] = st.get("messages", []) + [{"role": "assistant", "content": msg}]
            st["last_route"] = "command"
            st["next_node"] = "end"
            return st

        product_name = parts[1].strip()
        st["active_product"] = product_name
        st["messages"] = st.get("messages", []) + [{"role": "assistant", "content": f"[system] active_product = {product_name}"}]
        st["last_route"] = "command"
        st["next_node"] = "end"
        return st

    if name == "/add_pass_to_individual_index":
        st = state.copy()
        # путь может содержать пробелы — берем весь хвост после команды
        prefix = "/add_pass_to_individual_index"
        rest = cmd[len(prefix):].strip()
        if not rest:
            msg = "Использование: /add_pass_to_individual_index <path>"
            st["messages"] = st.get("messages", []) + [{"role": "assistant", "content": msg}]
            st["last_route"] = "command"
            st["next_node"] = "end"
            return st

        passport_path = _strip_quotes(rest)
        st["individual_passport_path"] = passport_path
        st["messages"] = st.get("messages", []) + [{"role": "assistant", "content": f"[system] starting individual indexing for: {passport_path}"}]
        st["last_route"] = "command"
        st["next_node"] = "individual_index"
        return st

    if name == "/clear":
        mode = state.get("mode") or settings.agent.mode
        st: AgentState = {
            "messages": [{"role": "assistant", "content": "[system] history cleared"}],
            "mode": mode,
            "active_product": None,
            "awaiting_user_clarification": False,
            "last_result": None,
            "last_route": "command",
            "last_classification": None,
            "next_node": "end",
            "individual_passport_path": None,
            "individual_last_dataset_uuid": None,
            "individual_last_index_id": None,
            "individual_last_output_path": None,
        }
        return st

    if name == "/state":
        msg = json.dumps(
            {
                "mode": state.get("mode"),
                "active_product": state.get("active_product"),
                "awaiting_user_clarification": state.get("awaiting_user_clarification"),
                "last_route": state.get("last_route"),
                "last_classification": state.get("last_classification"),
                "individual": {
                    "last_dataset_uuid": state.get("individual_last_dataset_uuid"),
                    "last_index_id": state.get("individual_last_index_id"),
                    "last_output_path": state.get("individual_last_output_path"),
                },
                "messages": len(state.get("messages", [])),
            },
            ensure_ascii=False,
            indent=2,
        )
        st = state.copy()
        st["messages"] = st.get("messages", []) + [{"role": "assistant", "content": msg}]
        st["last_route"] = "command"
        st["next_node"] = "end"
        return st

    st = state.copy()
    st["messages"] = st.get("messages", []) + [{"role": "assistant", "content": "Неизвестная команда. /help"}]
    st["last_route"] = "command"
    st["next_node"] = "end"
    return st


def preprocess_node(state: AgentState, settings: AppSettings) -> AgentState:
    st = state.copy()
    msgs = st.get("messages", [])
    if not msgs or msgs[-1].get("role") != "user":
        st["next_node"] = "end"
        return st

    user_text = normalize_user_text(msgs[-1].get("content", ""))
    msgs[-1]["content"] = user_text
    st["messages"] = msgs

    cmd_state = handle_command(st, user_text, settings)
    if cmd_state is not None:
        return cmd_state

    mode = (st.get("mode") or settings.agent.mode or "rag").lower()
    if mode not in ("rag", "norag", "auto"):
        mode = "rag"
    st["mode"] = mode

    cls = classify_query(
        user_text,
        known_products=settings.domain.known_products,
        active_product=st.get("active_product"),
    )
    st["last_classification"] = cls

    if not st.get("active_product") and cls.get("product"):
        st["active_product"] = cls["product"]

    if mode == "auto":
        st["next_node"] = cls.get("route") or "rag"
    else:
        st["next_node"] = mode

    return st


def rag_node(state: AgentState, *, client: GigaSearchClient, settings: AppSettings, search_cfg_rag: Dict[str, Any]) -> AgentState:
    st = state.copy()
    msgs = st.get("messages", [])
    if not msgs or msgs[-1].get("role") != "user":
        st["next_node"] = "end"
        return st

    msgs_for_llm = trim_history(
        msgs,
        keep_last_user_turns=settings.agent.keep_last_user_turns,
        awaiting_clarification=bool(st.get("awaiting_user_clarification")),
    )

    if st.get("active_product"):
        result = client.chat_messages_with_product_filter(
            messages=msgs_for_llm,
            product_name=st["active_product"],
            search_config=search_cfg_rag,
        )
    else:
        result = client.chat_messages(messages=msgs_for_llm, search_config=search_cfg_rag)

    answer_text = extract_agent_text(result)
    clarification = is_clarification(answer_text)

    new_messages = msgs + [{"role": "assistant", "content": answer_text}]
    new_messages = trim_history(
        new_messages,
        keep_last_user_turns=settings.agent.keep_last_user_turns,
        awaiting_clarification=clarification,
    )

    st.update({
        "messages": new_messages,
        "last_result": result,
        "awaiting_user_clarification": clarification,
        "last_route": "rag",
        "next_node": "end",
    })
    return st


def norag_node(state: AgentState, *, client: GigaSearchClient, settings: AppSettings, search_cfg_norag: Dict[str, Any]) -> AgentState:
    st = state.copy()
    msgs = st.get("messages", [])
    if not msgs or msgs[-1].get("role") != "user":
        st["next_node"] = "end"
        return st

    msgs_for_llm = trim_history(
        msgs,
        keep_last_user_turns=settings.agent.keep_last_user_turns,
        awaiting_clarification=bool(st.get("awaiting_user_clarification")),
    )

    result = client.chat_messages(messages=msgs_for_llm, search_config=search_cfg_norag)

    answer_text = extract_agent_text(result)
    clarification = is_clarification(answer_text)

    new_messages = msgs + [{"role": "assistant", "content": answer_text}]
    new_messages = trim_history(
        new_messages,
        keep_last_user_turns=settings.agent.keep_last_user_turns,
        awaiting_clarification=clarification,
    )

    st.update({
        "messages": new_messages,
        "last_result": result,
        "awaiting_user_clarification": clarification,
        "last_route": "norag",
        "next_node": "end",
    })
    return st


def individual_index_node(state: AgentState, *, client: GigaSearchClient, settings: AppSettings) -> AgentState:
    st = state.copy()
    passport_path = st.get("individual_passport_path")
    if not passport_path:
        st["messages"] = st.get("messages", []) + [{"role": "assistant", "content": "[error] individual_passport_path is empty"}]
        st["next_node"] = "end"
        return st

    try:
        res = run_add_pass_to_individual_index(client=client, settings=settings, passport_path=passport_path)
        st["individual_last_dataset_uuid"] = res.dataset_uuid
        st["individual_last_index_id"] = res.index_id
        st["individual_last_output_path"] = res.output_path

        msg = (
            "✅ Individual index готов\n"
            f"- dataset_uuid: {res.dataset_uuid}\n"
            f"- index_uuid:   {res.index_uuid}\n"
            f"- index_id:     {res.index_id}\n"
            f"- answers_json: {res.output_path}"
        )
        st["messages"] = st.get("messages", []) + [{"role": "assistant", "content": msg}]
        st["last_route"] = "individual_index"
        st["next_node"] = "end"
        return st
    except Exception as e:
        st["messages"] = st.get("messages", []) + [{"role": "assistant", "content": f"[error] {type(e).__name__}: {e}"}]
        st["last_route"] = "individual_index"
        st["next_node"] = "end"
        return st
