from typing import Any, Dict

from langgraph.graph import StateGraph, END

from gigasearch.client import GigaSearchClient

from .settings import AppSettings
from .state import AgentState
from .nodes import preprocess_node, rag_node, norag_node, individual_index_node


def build_agent_graph(
    *,
    client: GigaSearchClient,
    settings: AppSettings,
    search_cfg_rag: Dict[str, Any],
    search_cfg_norag: Dict[str, Any],
):
    graph = StateGraph(AgentState)

    graph.add_node("preprocess", lambda s: preprocess_node(s, settings))
    graph.add_node("rag", lambda s: rag_node(s, client=client, settings=settings, search_cfg_rag=search_cfg_rag))
    graph.add_node("norag", lambda s: norag_node(s, client=client, settings=settings, search_cfg_norag=search_cfg_norag))
    graph.add_node("individual_index", lambda s: individual_index_node(s, client=client, settings=settings))

    def router(s: AgentState) -> str:
        return (s.get("next_node") or "end")

    graph.add_conditional_edges(
        "preprocess",
        router,
        {
            "rag": "rag",
            "norag": "norag",
            "individual_index": "individual_index",
            "end": END,
        },
    )

    graph.add_edge("rag", END)
    graph.add_edge("norag", END)
    graph.add_edge("individual_index", END)

    graph.set_entry_point("preprocess")
    return graph.compile()
