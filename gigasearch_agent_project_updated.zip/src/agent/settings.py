import json
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

import yaml

from gigasearch.utils import ensure_cert_tuple


@dataclass(frozen=True)
class GigaSearchSettings:
    base_url: str
    source_uuid: str
    cert: Tuple[str, str]
    verify_ssl: bool
    timeout_sec: int


@dataclass(frozen=True)
class AgentSettings:
    state_path: str
    mode: str  # rag|norag|auto
    keep_last_user_turns: int
    product_filter_field: str


@dataclass(frozen=True)
class PathsSettings:
    search_rag_path: str
    search_norag_path: str
    prompts_strict_path: Optional[str] = None

    search_individual_stuff_path: Optional[str] = None
    individual_questions_path: Optional[str] = None
    data_enrichment_config_path: Optional[str] = None
    indexer_config_path: Optional[str] = None
    individual_outputs_dir: Optional[str] = None


@dataclass(frozen=True)
class DomainSettings:
    known_products: List[str]


@dataclass(frozen=True)
class AppSettings:
    gigasearch: GigaSearchSettings
    agent: AgentSettings
    paths: PathsSettings
    domain: DomainSettings


def load_yaml(path: str) -> Dict[str, Any]:
    p = Path(path)
    with p.open("r", encoding="utf-8") as f:
        return yaml.safe_load(f) or {}


def load_json(path: str) -> Dict[str, Any]:
    p = Path(path)
    with p.open("r", encoding="utf-8") as f:
        return json.load(f)


def deep_update(base: Dict[str, Any], patch: Dict[str, Any]) -> Dict[str, Any]:
    out = json.loads(json.dumps(base))
    stack = [(out, patch)]
    while stack:
        dst, src = stack.pop()
        for k, v in (src or {}).items():
            if isinstance(v, dict) and isinstance(dst.get(k), dict):
                stack.append((dst[k], v))
            else:
                dst[k] = v
    return out


def _resolve_path(base_dir: Path, maybe_path: Optional[str]) -> Optional[str]:
    if not maybe_path:
        return None
    p = Path(str(maybe_path))
    if p.is_absolute():
        return str(p)
    return str((base_dir / p).resolve())


def load_settings(app_yaml_path: str) -> AppSettings:
    app_yaml = Path(app_yaml_path).resolve()
    base_dir = app_yaml.parent
    cfg = load_yaml(str(app_yaml))

    gs = cfg.get("gigasearch") or {}
    cert_cfg = (gs.get("cert") or {})
    cert = ensure_cert_tuple(
        _resolve_path(base_dir, str(cert_cfg.get("crt_path", ""))) or "",
        _resolve_path(base_dir, str(cert_cfg.get("key_path", ""))) or "",
    )

    paths = cfg.get("paths") or {}
    agent = cfg.get("agent") or {}
    domain = cfg.get("domain") or {}

    return AppSettings(
        gigasearch=GigaSearchSettings(
            base_url=gs.get("base_url", ""),
            source_uuid=gs.get("source_uuid", ""),
            cert=cert,
            verify_ssl=bool(gs.get("verify_ssl", False)),
            timeout_sec=int(gs.get("timeout_sec", 600)),
        ),
        paths=PathsSettings(
            search_rag_path=_resolve_path(base_dir, str(paths.get("search_rag_path", ""))) or "",
            search_norag_path=_resolve_path(base_dir, str(paths.get("search_norag_path", ""))) or "",
            prompts_strict_path=_resolve_path(base_dir, str(paths.get("prompts_strict_path"))) if paths.get("prompts_strict_path") else None,

            search_individual_stuff_path=_resolve_path(base_dir, str(paths.get("search_individual_stuff_path"))) if paths.get("search_individual_stuff_path") else None,
            individual_questions_path=_resolve_path(base_dir, str(paths.get("individual_questions_path"))) if paths.get("individual_questions_path") else None,
            data_enrichment_config_path=_resolve_path(base_dir, str(paths.get("data_enrichment_config_path"))) if paths.get("data_enrichment_config_path") else None,
            indexer_config_path=_resolve_path(base_dir, str(paths.get("indexer_config_path"))) if paths.get("indexer_config_path") else None,
            individual_outputs_dir=_resolve_path(base_dir, str(paths.get("individual_outputs_dir"))) if paths.get("individual_outputs_dir") else None,
        ),
        agent=AgentSettings(
            state_path=_resolve_path(base_dir, str(agent.get("state_path", "./.state/agent_state.json"))) or "./.state/agent_state.json",
            mode=str(agent.get("mode", "rag")).lower(),
            keep_last_user_turns=int(agent.get("keep_last_user_turns", 3)),
            product_filter_field=str(agent.get("product_filter_field", "product_name")),
        ),
        domain=DomainSettings(known_products=list(domain.get("known_products") or [])),
    )
