import json
import re
import time
from dataclasses import dataclass
from difflib import SequenceMatcher
from pathlib import Path
from typing import Any, Dict, List, Optional, Tuple

from gigasearch.client import GigaSearchClient
from gigasearch.utils import uuid4_str

from .settings import AppSettings, deep_update, load_json, load_yaml
from .state import extract_agent_text

DEFAULT_UNKNOWN_ANSWER = "Информация по данному вопросу в паспорте продукта отсутствует."


@dataclass(frozen=True)
class IndividualFlowResult:
    dataset_uuid: str
    index_uuid: str
    index_id: str
    output_path: str
    answers: List[Dict[str, Any]]


def _now_iso() -> str:
    return time.strftime("%Y-%m-%dT%H:%M:%S", time.localtime())


def _safe_stem(stem: str) -> str:
    s = (stem or "").strip()
    s = re.sub(r'[<>:"/\\|?*]', "_", s)
    s = re.sub(r"\s+", "_", s)
    s = re.sub(r"_+", "_", s)
    return s[:120] or "passport"


def patch_index_id(search_cfg: Dict[str, Any], index_id: str) -> Dict[str, Any]:
    return deep_update(
        search_cfg,
        {"agent_configuration": {"data_sources": [{"index_id": index_id}]}},
    )


def _read_questions_cfg(path: str) -> Tuple[int, str, List[Dict[str, Any]]]:
    cfg = load_json(path)
    batch_size = int(cfg.get("prompt_batch_size") or 1)
    if batch_size < 1:
        batch_size = 1
    unknown_answer = str(cfg.get("unknown_answer") or DEFAULT_UNKNOWN_ANSWER)
    data = cfg.get("data") or []
    if not isinstance(data, list) or not data:
        raise ValueError(f"Questions config has no 'data' list: {path}")
    return batch_size, unknown_answer, data


def _parse_options(options: Optional[str]) -> List[str]:
    if not options:
        return []
    raw = str(options)
    lines = []
    for line in raw.splitlines():
        line = line.strip()
        line = re.sub(r"^[•\-\*\d\)\.\s]+", "", line).strip()
        if line:
            lines.append(line)
    # если всё было в одной строке — оставим как есть (строго)
    return lines


def _norm(s: str) -> str:
    s = (s or "").strip().lower()
    s = re.sub(r"\s+", " ", s)
    s = re.sub(r'[“”‘’"]', "", s)
    return s


def _best_match(token: str, options: List[str]) -> Optional[str]:
    nt = _norm(token)
    if not nt:
        return None

    # exact
    for opt in options:
        if _norm(opt) == nt:
            return opt

    # substring (осторожно)
    for opt in options:
        no = _norm(opt)
        if nt == no:
            return opt
        if nt in no and len(nt) >= 4:
            return opt

    # fuzzy
    best = None
    best_score = 0.0
    for opt in options:
        score = SequenceMatcher(None, nt, _norm(opt)).ratio()
        if score > best_score:
            best_score = score
            best = opt

    if best and best_score >= 0.80:
        return best
    return None


def enforce_options(answer: str, options: List[str], unknown_answer: str) -> str:
    """Гарантируем: итоговый ответ состоит только из значений из options (или unknown/уточнение)."""
    a = (answer or "").strip()
    if not a:
        return unknown_answer

    # если модель уже вернула unknown — оставляем
    if _norm(a) == _norm(unknown_answer):
        return unknown_answer

    if not options:
        # нет списка вариантов — оставляем как есть
        return a

    # split answer into candidate tokens
    cleaned = re.sub(r"^[•\-\*\s]+", "", a).strip()
    parts = [p.strip() for p in re.split(r"[\n,;]+", cleaned) if p.strip()]

    selected: List[str] = []
    for p in parts:
        m = _best_match(p, options)
        if m and m not in selected:
            selected.append(m)

    if selected:
        return ", ".join(selected)

    # ничего не распознали — если есть вариант "Требуется уточнение" используем его
    for opt in options:
        if _norm(opt) == _norm("Требуется уточнение"):
            return opt

    return unknown_answer


def _build_batch_task(batch_questions: List[Dict[str, Any]], unknown_answer: str) -> str:
    lines: List[str] = []
    lines.append(
        "Заполни ответы на вопросы по паспорту инвестиционного продукта. "
        "Отвечай строго по тексту паспорта (контекст будет передан отдельно)."
    )
    lines.append(
        "Верни ТОЛЬКО валидный JSON-массив объектов формата: "
        "[{\"question\": string, \"answer\": string}, ...]."
    )
    lines.append(
        f"Если ответа нет — укажи answer: {json.dumps(unknown_answer, ensure_ascii=False)}."
    )
    lines.append(
        "ВАЖНО: если у вопроса есть список вариантов ответа, то answer должен состоять ТОЛЬКО из значений из списка "
        "(один или несколько; если несколько — перечисли через запятую)."
    )
    lines.append("\nВОПРОСЫ:")

    for i, q in enumerate(batch_questions, start=1):
        qq = str(q.get("question") or "").strip()
        if not qq:
            continue
        lines.append(f"\n{i}. {qq}")

        if bool(q.get("has_options")) and q.get("answer_options"):
            lines.append("Варианты ответа (строго из этого списка):")
            lines.append(str(q.get("answer_options")))

    return "\n".join(lines).strip()


def _extract_json_block(text: str) -> Optional[Any]:
    if not text:
        return None

    t = text.strip()
    t = re.sub(r"^\s*FINAL\s+ANSWER\s*:\s*", "", t, flags=re.IGNORECASE)

    if "```" in t:
        parts = re.split(r"```(?:json)?", t, flags=re.IGNORECASE)
        cand = max((p.strip() for p in parts if p.strip()), key=len, default="")
        if cand:
            t = cand

    m = re.search(r"\[.*\]", t, flags=re.DOTALL)
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            pass

    m = re.search(r"\{.*\}", t, flags=re.DOTALL)
    if m:
        try:
            return json.loads(m.group(0))
        except Exception:
            pass

    return None


def _normalize_question_key(q: str) -> str:
    return re.sub(r"\s+", " ", (q or "").strip().lower())


def _answers_from_parsed(parsed: Any, batch_questions: List[Dict[str, Any]], unknown_answer: str) -> Optional[List[Dict[str, Any]]]:
    if isinstance(parsed, dict):
        if isinstance(parsed.get("answers"), list):
            parsed_list = parsed["answers"]
        else:
            parsed_list = [{"question": k, "answer": v} for k, v in parsed.items() if isinstance(k, str)]
    elif isinstance(parsed, list):
        parsed_list = parsed
    else:
        return None

    by_q: Dict[str, str] = {}
    for obj in parsed_list:
        if not isinstance(obj, dict):
            continue
        q = obj.get("question")
        a = obj.get("answer")
        if isinstance(q, str) and q.strip():
            by_q[_normalize_question_key(q)] = str(a) if a is not None else ""

    items: List[Dict[str, Any]] = []
    for q_cfg in batch_questions:
        q_text = str(q_cfg.get("question") or "").strip()
        if not q_text:
            continue

        answer = by_q.get(_normalize_question_key(q_text)) or ""
        if not answer:
            answer = unknown_answer

        # strict options enforcement
        if bool(q_cfg.get("has_options")):
            options = _parse_options(q_cfg.get("answer_options"))
            answer = enforce_options(answer, options, unknown_answer)

        items.append(
            {
                "question": q_text,
                "answer": answer,
                "has_options": bool(q_cfg.get("has_options")),
                "answer_options": q_cfg.get("answer_options"),
            }
        )
    return items


def _ask_batch(client: GigaSearchClient, search_cfg: Dict[str, Any], batch_questions: List[Dict[str, Any]], unknown_answer: str) -> List[Dict[str, Any]]:
    task = _build_batch_task(batch_questions, unknown_answer=unknown_answer)
    result = client.search_query(query=task, search_config=search_cfg)
    text = extract_agent_text(result)
    parsed = _extract_json_block(text)
    answers = _answers_from_parsed(parsed, batch_questions, unknown_answer) if parsed is not None else None
    if answers is None:
        raise ValueError("LLM response is not valid JSON or unexpected format")
    return answers


def run_add_pass_to_individual_index(*, client: GigaSearchClient, settings: AppSettings, passport_path: str) -> IndividualFlowResult:
    p = Path(passport_path)
    if not p.exists():
        raise FileNotFoundError(str(p))

    # validate settings
    if not settings.paths.data_enrichment_config_path:
        raise ValueError("paths.data_enrichment_config_path is not set")
    if not settings.paths.indexer_config_path:
        raise ValueError("paths.indexer_config_path is not set")
    if not settings.paths.search_individual_stuff_path:
        raise ValueError("paths.search_individual_stuff_path is not set")
    if not settings.paths.individual_questions_path:
        raise ValueError("paths.individual_questions_path is not set")

    de_cfg = load_yaml(settings.paths.data_enrichment_config_path)
    indexer_cfg = load_json(settings.paths.indexer_config_path)
    stuff_cfg_template = load_json(settings.paths.search_individual_stuff_path)
    batch_size, unknown_answer, questions_cfg = _read_questions_cfg(settings.paths.individual_questions_path)

    dataset_uuid = client.create_dataset(de_cfg)

    stem = _safe_stem(p.stem)
    client.upload_files(dataset_uuid, str(p), product_name=stem)

    client.save_dataset_version(dataset_uuid)
    client.wait_last_version_done(dataset_uuid)

    index_id = f"{uuid4_str()}_{stem}_individual_index"
    index_uuid = client.create_index(dataset_uuid, indexer_cfg, index_id=index_id)
    client.update_index(index_uuid)
    index_status = client.wait_index_done(index_uuid)
    final_index_id = str(index_status.get("index_id") or index_id)

    stuff_cfg = patch_index_id(stuff_cfg_template, final_index_id)

    answers: List[Dict[str, Any]] = []
    total = len(questions_cfg)
    for i in range(0, total, batch_size):
        batch = questions_cfg[i:i + batch_size]
        # batch ask; если не получилось — пробуем по одному, но всё равно строго валидируем options
        try:
            answers.extend(_ask_batch(client, stuff_cfg, batch, unknown_answer=unknown_answer))
        except Exception:
            # fallback: one-by-one
            for q in batch:
                try:
                    answers.extend(_ask_batch(client, stuff_cfg, [q], unknown_answer=unknown_answer))
                except Exception:
                    # last-resort: unknown (and enforce)
                    q_text = str(q.get("question") or "").strip()
                    ans = unknown_answer
                    if bool(q.get("has_options")):
                        opts = _parse_options(q.get("answer_options"))
                        ans = enforce_options(ans, opts, unknown_answer)
                    answers.append(
                        {
                            "question": q_text,
                            "answer": ans,
                            "has_options": bool(q.get("has_options")),
                            "answer_options": q.get("answer_options"),
                        }
                    )

    out_dir = Path(settings.paths.individual_outputs_dir or "./outputs/individual_answers")
    out_dir.mkdir(parents=True, exist_ok=True)

    out_path = out_dir / f"{stem}.json"
    if out_path.exists():
        out_path = out_dir / f"{stem}__{time.strftime('%Y%m%d_%H%M%S')}.json"

    payload = {
        "generated_at": _now_iso(),
        "passport": {"path": str(p), "file_name": p.name, "stem": stem},
        "dataset_uuid": dataset_uuid,
        "index_uuid": index_uuid,
        "index_id": final_index_id,
        "answers": answers,
    }

    out_path.write_text(json.dumps(payload, ensure_ascii=False, indent=2), encoding="utf-8")

    return IndividualFlowResult(
        dataset_uuid=dataset_uuid,
        index_uuid=index_uuid,
        index_id=final_index_id,
        output_path=str(out_path),
        answers=answers,
    )
