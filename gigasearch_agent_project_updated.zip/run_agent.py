import json
import logging
import sys
import warnings
from pathlib import Path

# --- make ./src importable ---
ROOT = Path(__file__).resolve().parent
SRC = ROOT / "src"
sys.path.insert(0, str(SRC))

from gigasearch import GigaSearchClient  # noqa: E402
from agent import build_agent_graph, FileStateStore, load_settings  # noqa: E402
from agent.settings import load_json, load_yaml, deep_update  # noqa: E402


def setup_warning_log(log_path: Path) -> None:
    """Redirect Python warnings to a file, so terminal stays clean."""
    log_path.parent.mkdir(parents=True, exist_ok=True)

    logging.basicConfig(
        filename=str(log_path),
        level=logging.WARNING,
        format="%(asctime)s %(levelname)s %(message)s",
    )

    def _showwarning(message, category, filename, lineno, file=None, line=None):
        logging.warning(
            "%s:%s: %s: %s",
            filename,
            lineno,
            getattr(category, "__name__", str(category)),
            message,
        )

    warnings.showwarning = _showwarning  # type: ignore
    warnings.filterwarnings("always")


def load_search_configs(settings):
    rag_cfg = load_json(settings.paths.search_rag_path)
    norag_cfg = load_json(settings.paths.search_norag_path)

    if settings.paths.prompts_strict_path:
        strict = load_yaml(settings.paths.prompts_strict_path) or {}
        strict_prompts = (strict.get("qa") or {}).get("prompts") or {}
        if strict_prompts:
            patch = {"agent_configuration": {"qa": {"prompts": strict_prompts}}}
            rag_cfg = deep_update(rag_cfg, patch)

    return rag_cfg, norag_cfg


def main():
    settings = load_settings(str(ROOT / "configs" / "app.yaml"))

    setup_warning_log(ROOT / "logs" / "warnings.log")

    rag_cfg, norag_cfg = load_search_configs(settings)

    client = GigaSearchClient(
        base_url=settings.gigasearch.base_url,
        source_uuid=settings.gigasearch.source_uuid,
        cert=settings.gigasearch.cert,
        verify_ssl=settings.gigasearch.verify_ssl,
        timeout_sec=settings.gigasearch.timeout_sec,
    )

    agent_graph = build_agent_graph(
        client=client,
        settings=settings,
        search_cfg_rag=rag_cfg,
        search_cfg_norag=norag_cfg,
    )

    store = FileStateStore(settings.agent.state_path)
    state = store.load(default_mode=settings.agent.mode)

    print("🤖 Investment Agent (LangGraph)")
    print("Команды: /help, /mode rag|norag|auto, /product <name>, /add_pass_to_individual_index <path>, /clear, /state, exit\n")

    while True:
        try:
            user_input = input("> ").strip()
        except (EOFError, KeyboardInterrupt):
            print("\n[system] exit")
            break

        if not user_input:
            continue

        if user_input.lower() in ("exit", "quit"):
            print("[system] exit")
            break

        msgs = state.get("messages", [])
        msgs.append({"role": "user", "content": user_input})
        state["messages"] = msgs

        try:
            state = agent_graph.invoke(state)
        except Exception as e:
            store.save(state)
            print(f"[error] {type(e).__name__}: {e}")
            continue

        store.save(state)

        if state.get("messages") and state["messages"][-1].get("role") == "assistant":
            print(state["messages"][-1]["content"])
        else:
            print("[system] (no assistant message)")
        print()

    try:
        store.save(state)
    except Exception:
        pass


if __name__ == "__main__":
    main()
